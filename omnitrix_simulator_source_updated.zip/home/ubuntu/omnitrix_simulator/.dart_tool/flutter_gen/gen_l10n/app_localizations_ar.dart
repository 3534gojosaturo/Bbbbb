import 'app_localizations.dart';

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get appTitle => 'محاكي الأومنيتركس';

  @override
  String get settingsTitle => 'الإعدادات';

  @override
  String get languageLabel => 'اللغة';

  @override
  String get soundLabel => 'الصوت';

  @override
  String get exitLabel => 'الخروج من التطبيق';

  @override
  String get transformButtonLabel => 'تحول';

  @override
  String get loadingText => 'جار التحميل...';

  @override
  String get transformingText => 'جار التحول...';

  @override
  String get humungousaurName => 'هومونغوصور';

  @override
  String get swampfireName => 'سوامب فاير';

  @override
  String get bigChillName => 'بيغ تشيل';

  @override
  String get spiderMonkeyName => 'سبايدر مونكي';

  @override
  String get echoEchoName => 'إيكو إيكو';

  @override
  String get cannonboltName => 'كانون بولت';

  @override
  String get wayBigName => 'واي بيغ';

  @override
  String get rathName => 'راث';

  @override
  String get waterHazardName => 'واتر هازارد';

  @override
  String get terraspinName => 'تيراسبين';

  @override
  String get nrgName => 'إن آر جي';

  @override
  String get armodrilloName => 'أرمودريلو';

  @override
  String get ampFibianName => 'أمفيبان';

  @override
  String get clockworkName => 'كلوكوورك';

  @override
  String get juryRiggName => 'جوري ريغ';

  @override
  String get eatleName => 'إيتل';

  @override
  String get ultimateHumungousaurName => 'ألتيمت هومونغوصور';

  @override
  String get ultimateSwampfireName => 'ألتيمت سوامب فاير';

  @override
  String get ultimateBigChillName => 'ألتيمت بيغ تشيل';

  @override
  String get ultimateSpiderMonkeyName => 'ألتيمت سبايدر مونكي';

  @override
  String get ultimateEchoEchoName => 'ألتيمت إيكو إيكو';

  @override
  String get ultimateCannonboltName => 'ألتيمت كانون بولت';

  @override
  String get ultimateWayBigName => 'ألتيمت واي بيغ';
}
