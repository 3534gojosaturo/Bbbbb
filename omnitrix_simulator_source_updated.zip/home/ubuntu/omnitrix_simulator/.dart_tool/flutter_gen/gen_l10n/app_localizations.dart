import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_ar.dart';
import 'app_localizations_en.dart';

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'gen_l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ar'),
    Locale('en')
  ];

  /// No description provided for @appTitle.
  ///
  /// In en, this message translates to:
  /// **'Omnitrix Simulator'**
  String get appTitle;

  /// No description provided for @settingsTitle.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get settingsTitle;

  /// No description provided for @languageLabel.
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get languageLabel;

  /// No description provided for @soundLabel.
  ///
  /// In en, this message translates to:
  /// **'Sound'**
  String get soundLabel;

  /// No description provided for @exitLabel.
  ///
  /// In en, this message translates to:
  /// **'Exit App'**
  String get exitLabel;

  /// No description provided for @transformButtonLabel.
  ///
  /// In en, this message translates to:
  /// **'Transform'**
  String get transformButtonLabel;

  /// No description provided for @loadingText.
  ///
  /// In en, this message translates to:
  /// **'Loading...'**
  String get loadingText;

  /// No description provided for @transformingText.
  ///
  /// In en, this message translates to:
  /// **'Transforming...'**
  String get transformingText;

  /// No description provided for @humungousaurName.
  ///
  /// In en, this message translates to:
  /// **'Humungousaur'**
  String get humungousaurName;

  /// No description provided for @swampfireName.
  ///
  /// In en, this message translates to:
  /// **'Swampfire'**
  String get swampfireName;

  /// No description provided for @bigChillName.
  ///
  /// In en, this message translates to:
  /// **'Big Chill'**
  String get bigChillName;

  /// No description provided for @spiderMonkeyName.
  ///
  /// In en, this message translates to:
  /// **'Spider-Monkey'**
  String get spiderMonkeyName;

  /// No description provided for @echoEchoName.
  ///
  /// In en, this message translates to:
  /// **'Echo Echo'**
  String get echoEchoName;

  /// No description provided for @cannonboltName.
  ///
  /// In en, this message translates to:
  /// **'Cannonbolt'**
  String get cannonboltName;

  /// No description provided for @wayBigName.
  ///
  /// In en, this message translates to:
  /// **'Way Big'**
  String get wayBigName;

  /// No description provided for @rathName.
  ///
  /// In en, this message translates to:
  /// **'Rath'**
  String get rathName;

  /// No description provided for @waterHazardName.
  ///
  /// In en, this message translates to:
  /// **'Water Hazard'**
  String get waterHazardName;

  /// No description provided for @terraspinName.
  ///
  /// In en, this message translates to:
  /// **'Terraspin'**
  String get terraspinName;

  /// No description provided for @nrgName.
  ///
  /// In en, this message translates to:
  /// **'NRG'**
  String get nrgName;

  /// No description provided for @armodrilloName.
  ///
  /// In en, this message translates to:
  /// **'Armodrillo'**
  String get armodrilloName;

  /// No description provided for @ampFibianName.
  ///
  /// In en, this message translates to:
  /// **'AmpFibian'**
  String get ampFibianName;

  /// No description provided for @clockworkName.
  ///
  /// In en, this message translates to:
  /// **'Clockwork'**
  String get clockworkName;

  /// No description provided for @juryRiggName.
  ///
  /// In en, this message translates to:
  /// **'Jury Rigg'**
  String get juryRiggName;

  /// No description provided for @eatleName.
  ///
  /// In en, this message translates to:
  /// **'Eatle'**
  String get eatleName;

  /// No description provided for @ultimateHumungousaurName.
  ///
  /// In en, this message translates to:
  /// **'Ultimate Humungousaur'**
  String get ultimateHumungousaurName;

  /// No description provided for @ultimateSwampfireName.
  ///
  /// In en, this message translates to:
  /// **'Ultimate Swampfire'**
  String get ultimateSwampfireName;

  /// No description provided for @ultimateBigChillName.
  ///
  /// In en, this message translates to:
  /// **'Ultimate Big Chill'**
  String get ultimateBigChillName;

  /// No description provided for @ultimateSpiderMonkeyName.
  ///
  /// In en, this message translates to:
  /// **'Ultimate Spider-Monkey'**
  String get ultimateSpiderMonkeyName;

  /// No description provided for @ultimateEchoEchoName.
  ///
  /// In en, this message translates to:
  /// **'Ultimate Echo Echo'**
  String get ultimateEchoEchoName;

  /// No description provided for @ultimateCannonboltName.
  ///
  /// In en, this message translates to:
  /// **'Ultimate Cannonbolt'**
  String get ultimateCannonboltName;

  /// No description provided for @ultimateWayBigName.
  ///
  /// In en, this message translates to:
  /// **'Ultimate Way Big'**
  String get ultimateWayBigName;
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['ar', 'en'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {


  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar': return AppLocalizationsAr();
    case 'en': return AppLocalizationsEn();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}
