import 'app_localizations.dart';

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'Omnitrix Simulator';

  @override
  String get settingsTitle => 'Settings';

  @override
  String get languageLabel => 'Language';

  @override
  String get soundLabel => 'Sound';

  @override
  String get exitLabel => 'Exit App';

  @override
  String get transformButtonLabel => 'Transform';

  @override
  String get loadingText => 'Loading...';

  @override
  String get transformingText => 'Transforming...';

  @override
  String get humungousaurName => 'Humungousaur';

  @override
  String get swampfireName => 'Swampfire';

  @override
  String get bigChillName => 'Big Chill';

  @override
  String get spiderMonkeyName => 'Spider-Monkey';

  @override
  String get echoEchoName => 'Echo Echo';

  @override
  String get cannonboltName => 'Cannonbolt';

  @override
  String get wayBigName => 'Way Big';

  @override
  String get rathName => 'Rath';

  @override
  String get waterHazardName => 'Water Hazard';

  @override
  String get terraspinName => 'Terraspin';

  @override
  String get nrgName => 'NRG';

  @override
  String get armodrilloName => 'Armodrillo';

  @override
  String get ampFibianName => 'AmpFibian';

  @override
  String get clockworkName => 'Clockwork';

  @override
  String get juryRiggName => 'Jury Rigg';

  @override
  String get eatleName => 'Eatle';

  @override
  String get ultimateHumungousaurName => 'Ultimate Humungousaur';

  @override
  String get ultimateSwampfireName => 'Ultimate Swampfire';

  @override
  String get ultimateBigChillName => 'Ultimate Big Chill';

  @override
  String get ultimateSpiderMonkeyName => 'Ultimate Spider-Monkey';

  @override
  String get ultimateEchoEchoName => 'Ultimate Echo Echo';

  @override
  String get ultimateCannonboltName => 'Ultimate Cannonbolt';

  @override
  String get ultimateWayBigName => 'Ultimate Way Big';
}
