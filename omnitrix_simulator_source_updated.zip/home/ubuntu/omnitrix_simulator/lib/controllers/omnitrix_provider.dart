import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:vibration/vibration.dart';
import '../models/alien.dart';
import '../views/alien_display_screen_2d.dart'; // Import 2D screen
import '../views/alien_display_screen_3d.dart'; // Import 3D screen

class OmnitrixProvider with ChangeNotifier {
  // List of available aliens (will be populated later)
  final List<Alien> _aliens = [
    // Placeholder - Actual aliens will be added later
    Alien(
      id: 'humungousaur',
      nameEn: 'Humungousaur',
      nameAr: 'هومونغوصور',
      imagePath: 'assets/images/humungousaur.png', // Placeholder path
      soundPath: 'assets/sounds/humungousaur_transform.mp3', // Placeholder path
      isUltimate: true, // Assuming Ultimate for 3D
      is3d: true,
      modelPath: 'assets/models/humungousaur.glb', // Placeholder path
    ),
    Alien(
      id: 'swampfire',
      nameEn: 'Swampfire',
      nameAr: 'سوامب فاير',
      imagePath: 'assets/images/swampfire.png', // Placeholder path
      soundPath: 'assets/sounds/swampfire_transform.mp3', // Placeholder path
    ),
    // TODO: Add more aliens based on the list in ui_mockups.md
    // Example:
    // Alien(
    //   id: 'bigchill',
    //   nameEn: 'Big Chill',
    //   nameAr: 'بيغ تشيل',
    //   imagePath: 'assets/images/big_chill.png',
    //   soundPath: 'assets/sounds/big_chill_transform.mp3',
    // ),
  ];

  int _selectedIndex = 0;
  bool _isTransforming = false;
  String _currentLanguage = 'en'; // Default language
  bool _isSoundEnabled = true;
  BuildContext? _context; // Store context for navigation

  final AudioPlayer _audioPlayer = AudioPlayer();

  List<Alien> get aliens => _aliens;
  int get selectedIndex => _selectedIndex;
  Alien get selectedAlien => _aliens[_selectedIndex];
  bool get isTransforming => _isTransforming;
  String get currentLanguage => _currentLanguage;
  bool get isSoundEnabled => _isSoundEnabled;

  // Set context for navigation
  void setContext(BuildContext context) {
    _context = context;
  }

  // Select next alien
  void selectNext() {
    if (_isTransforming) return;
    _selectedIndex = (_selectedIndex + 1) % _aliens.length;
    _playSound('assets/sounds/selection_tick.mp3'); // Placeholder selection sound
    notifyListeners();
  }

  // Select previous alien
  void selectPrevious() {
    if (_isTransforming) return;
    _selectedIndex = (_selectedIndex - 1 + _aliens.length) % _aliens.length;
     _playSound('assets/sounds/selection_tick.mp3'); // Placeholder selection sound
    notifyListeners();
  }

  // Select alien by index (e.g., from dial)
  void selectAlien(int index) {
    if (_isTransforming) return;
    if (index >= 0 && index < _aliens.length) {
      _selectedIndex = index;
      _playSound('assets/sounds/selection_tick.mp3'); // Placeholder selection sound
      notifyListeners();
    }
  }

  // Initiate transformation
  Future<void> transform() async {
    if (_isTransforming || _context == null) return;

    _isTransforming = true;
    notifyListeners();

    // Play transformation start sound
    _playSound('assets/sounds/transform_start.mp3'); // Placeholder start sound

    // Vibrate if possible
    try {
      bool? hasVibrator = await Vibration.hasVibrator();
      if (hasVibrator ?? false) {
        Vibration.vibrate(duration: 300);
      }
    } catch (e) {
      print("Vibration error: $e");
    }

    // Simulate transformation delay // and play specific alien sound
    await Future.delayed(const Duration(milliseconds: 500)); // Initial delay for start sound/vibration
    // _playSound(selectedAlien.soundPath); // Removed as per user request
    await Future.delayed(const Duration(seconds: 2)); // Transformation animation duration

    // Navigate to the appropriate screen
    if (_context != null && _context!.mounted) { // Check if context is still valid
       Navigator.push(
         _context!,
         MaterialPageRoute(
           builder: (context) => selectedAlien.is3d
               ? AlienDisplayScreen3D(alien: selectedAlien)
               : AlienDisplayScreen2D(alien: selectedAlien),
         ),
       );
    }

    _isTransforming = false;
    // Delay notifyListeners slightly to allow navigation animation to start
    await Future.delayed(const Duration(milliseconds: 100));
    if (_context != null && _context!.mounted) {
        notifyListeners();
    }

  }

  // Play sound helper function
  Future<void> _playSound(String soundPath) async {
    if (_isSoundEnabled && soundPath.isNotEmpty) {
      try {
        // Ensure path format is correct for AssetSource
        String assetPath = soundPath;
        if (assetPath.startsWith('assets/')) {
          assetPath = assetPath.substring('assets/'.length);
        }
        await _audioPlayer.play(AssetSource(assetPath));
      } catch (e) {
        print("Error playing sound '$soundPath': $e");
        // Handle error, maybe log it or show a message
      }
    }
  }

  // Toggle sound setting
  void toggleSound() {
    _isSoundEnabled = !_isSoundEnabled;
    if (!_isSoundEnabled) {
      _audioPlayer.stop(); // Stop any currently playing sound
    }
    notifyListeners();
  }

  // Change language setting
  void setLanguage(String languageCode) {
    if (_currentLanguage != languageCode && (languageCode == 'en' || languageCode == 'ar')) {
      _currentLanguage = languageCode;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }
}

