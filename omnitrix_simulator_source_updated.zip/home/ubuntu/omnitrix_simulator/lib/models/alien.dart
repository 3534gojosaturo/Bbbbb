// Represents an alien transformation
class Alien {
  final String id;
  final String nameEn;
  final String nameAr;
  final String imagePath; // Path to the 2D image
  final String soundPath; // Path to the transformation sound
  final bool isUltimate; // Is it an ultimate form?
  final bool is3d; // Does it have a 3D model?
  final String? modelPath; // Path to the 3D model (if is3d is true)
  final String? quoteEn; // Optional quote
  final String? quoteAr; // Optional quote

  Alien({
    required this.id,
    required this.nameEn,
    required this.nameAr,
    required this.imagePath,
    required this.soundPath,
    this.isUltimate = false,
    this.is3d = false,
    this.modelPath,
    this.quoteEn,
    this.quoteAr,
  });

  // Method to get localized name
  String getLocalizedName(String languageCode) {
    return languageCode == 'ar' ? nameAr : nameEn;
  }

  // Method to get localized quote
  String? getLocalizedQuote(String languageCode) {
    return languageCode == 'ar' ? quoteAr : quoteEn;
  }
}

