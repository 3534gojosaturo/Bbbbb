import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/omnitrix_provider.dart';
import '../models/alien.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class AlienDisplayScreen2D extends StatelessWidget {
  final Alien alien;

  const AlienDisplayScreen2D({super.key, required this.alien});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final omnitrixProvider = Provider.of<OmnitrixProvider>(context, listen: false);

    // Helper to get localized alien name based on ID
    String _getLocalizedAlienName(BuildContext context, Alien alien) {
      switch (alien.id) {
        case 'humungousaur':
          return alien.isUltimate ? l10n.ultimateHumungousaurName : l10n.humungousaurName;
        case 'swampfire':
          return alien.isUltimate ? l10n.ultimateSwampfireName : l10n.swampfireName;
        // Add other cases
        default:
          return alien.getLocalizedName(omnitrixProvider.currentLanguage);
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(_getLocalizedAlienName(context, alien)),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Placeholder for Alien Image
            // TODO: Load actual image from alien.imagePath
            Container(
              width: MediaQuery.of(context).size.width * 0.8,
              height: MediaQuery.of(context).size.height * 0.5,
              color: Colors.grey[800],
              child: Center(
                child: Text(
                  'Image Placeholder for\n${_getLocalizedAlienName(context, alien)}',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
            SizedBox(height: 20),
            // Optional: Play quote/sound on entry (handled by provider?)
            // Optional: Back button (AppBar provides one)
          ],
        ),
      ),
    );
  }
}

