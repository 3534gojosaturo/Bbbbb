import 'package:flutter/material.dart';
import 'dart:math' as math;

class OmnitrixDial extends StatefulWidget {
  final double size;
  final Color color;
  final Color accentColor;
  final VoidCallback onRotateClockwise;
  final VoidCallback onRotateCounterClockwise;
  // TODO: Add parameter for selected alien symbol/image

  const OmnitrixDial({
    super.key,
    required this.size,
    required this.color,
    required this.accentColor,
    required this.onRotateClockwise,
    required this.onRotateCounterClockwise,
  });

  @override
  _OmnitrixDialState createState() => _OmnitrixDialState();
}

class _OmnitrixDialState extends State<OmnitrixDial> {
  double _currentAngle = 0.0;
  Offset? _lastPosition;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanStart: (details) {
        _lastPosition = details.localPosition;
      },
      onPanUpdate: (details) {
        if (_lastPosition == null) return;

        final center = Offset(widget.size / 2, widget.size / 2);
        final previousVector = _lastPosition! - center;
        final currentVector = details.localPosition - center;

        final angleDelta = currentVector.direction - previousVector.direction;

        // Basic threshold to detect rotation direction
        if (angleDelta > 0.05) { // Clockwise threshold
          widget.onRotateClockwise();
          _lastPosition = details.localPosition; // Update last position to prevent rapid calls
        } else if (angleDelta < -0.05) { // Counter-clockwise threshold
          widget.onRotateCounterClockwise();
          _lastPosition = details.localPosition; // Update last position
        }

        // Update angle for visual rotation (optional, can be complex)
        // setState(() {
        //   _currentAngle += angleDelta;
        // });

        // _lastPosition = details.localPosition; // Continuous update (can be too sensitive)
      },
      onPanEnd: (details) {
        _lastPosition = null;
      },
      child: Transform.rotate(
        angle: _currentAngle, // Apply visual rotation if needed
        child: Container(
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.grey[900], // Dark grey base
            border: Border.all(
              color: Colors.black, // Black border for depth
              width: 6,
            ),
            boxShadow: [
              BoxShadow(
                color: widget.color.withOpacity(0.8), // Green glow
                blurRadius: 15,
                spreadRadius: 5,
              ),
            ],
          ),
          child: Center(
            // Placeholder for the 'X' symbol or alien icon
            // TODO: Draw the actual Ultimate Omnitrix 'X' shape or show alien symbol
            child: Icon(
              Icons.shield_outlined, // Placeholder icon
              color: widget.color, // Green
              size: widget.size * 0.5,
            ),
          ),
        ),
      ),
    );
  }
}

