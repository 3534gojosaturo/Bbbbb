import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:model_viewer_plus/model_viewer_plus.dart'; // Import model_viewer_plus
import '../controllers/omnitrix_provider.dart';
import '../models/alien.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class AlienDisplayScreen3D extends StatelessWidget {
  final Alien alien;

  const AlienDisplayScreen3D({super.key, required this.alien});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final omnitrixProvider = Provider.of<OmnitrixProvider>(context, listen: false);
    final modelPath = 'assets/models/humungousaur_rigged_model.glb'; // Path to the model provided by user

    // Helper to get localized alien name based on ID
    String _getLocalizedAlienName(BuildContext context, Alien alien) {
      switch (alien.id) {
        case 'humungousaur':
          // Assuming the provided model is Ultimate Humungousaur based on the requirement
          // If it's regular Humungousaur, adjust the logic or name
          return l10n.ultimateHumungousaurName; // Or l10n.humungousaurName
        default:
          return alien.getLocalizedName(omnitrixProvider.currentLanguage);
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(_getLocalizedAlienName(context, alien)),
        backgroundColor: Colors.transparent, // Make AppBar transparent
        elevation: 0,
      ),
      backgroundColor: Colors.black, // Keep background black
      body: Container(
        // Add glowing effect around the ModelViewer using a BoxDecoration
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Theme.of(context).colorScheme.primary.withOpacity(0.6), // Green glow
              blurRadius: 30,
              spreadRadius: 10,
            ),
          ],
        ),
        child: Center(
          child: ModelViewer(
            src: modelPath,
            alt: _getLocalizedAlienName(context, alien), // Accessibility description
            ar: false, // Disable AR if not needed
            autoRotate: true, // Enable auto-rotation as requested (short animation)
            cameraControls: true, // Allow user rotation
            backgroundColor: Colors.transparent, // Make viewer background transparent
            // TODO: Add loading indicator
            // TODO: Handle potential loading errors
            // TODO: Consider adding specific animations if the model supports them
          ),
        ),
      ),
    );
  }
}

