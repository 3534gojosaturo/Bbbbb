import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../controllers/omnitrix_provider.dart';
import 'dart:io'; // Import for exit()

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final omnitrixProvider = Provider.of<OmnitrixProvider>(context);
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.settingsTitle),
      ),
      body: ListView(
        children: <Widget>[
          // Language Toggle
          ListTile(
            title: Text(l10n.languageLabel),
            trailing: DropdownButton<String>(
              value: omnitrixProvider.currentLanguage,
              onChanged: (String? newValue) {
                if (newValue != null) {
                  omnitrixProvider.setLanguage(newValue);
                }
              },
              items: <String>['en', 'ar']
                  .map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value == 'en' ? 'English' : 'العربية'),
                );
              }).toList(),
            ),
          ),
          Divider(),
          // Sound Toggle
          SwitchListTile(
            title: Text(l10n.soundLabel),
            value: omnitrixProvider.isSoundEnabled,
            onChanged: (bool value) {
              omnitrixProvider.toggleSound();
            },
            secondary: Icon(omnitrixProvider.isSoundEnabled ? Icons.volume_up : Icons.volume_off),
          ),
          Divider(),
          // Exit Button
          ListTile(
            title: Text(l10n.exitLabel, style: TextStyle(color: Colors.redAccent)),
            leading: Icon(Icons.exit_to_app, color: Colors.redAccent),
            onTap: () {
              // Close the app
              // Note: exit(0) is generally discouraged in mobile apps, especially iOS.
              // A better approach might be just navigating back or letting the OS handle it.
              // However, fulfilling the explicit requirement:
              exit(0);
            },
          ),
          Divider(),
        ],
      ),
    );
  }
}

