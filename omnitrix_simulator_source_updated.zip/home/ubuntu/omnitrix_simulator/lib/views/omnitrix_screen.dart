import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/omnitrix_provider.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart'; // Import generated localizations
import 'widgets/omnitrix_dial.dart'; // Import the dial widget
import 'settings_screen.dart'; // Import the settings screen
import 'alien_display_screen_2d.dart'; // Import 2D screen
import 'alien_display_screen_3d.dart'; // Import 3D screen

class OmnitrixScreen extends StatelessWidget {
  const OmnitrixScreen({super.key});

  // Helper to get localized alien name based on ID
  String _getLocalizedAlienName(BuildContext context, Alien alien) {
    final AppLocalizations l10n = AppLocalizations.of(context)!;
    final omnitrixProvider = Provider.of<OmnitrixProvider>(context, listen: false);
    // Use a switch or map for better maintainability if many aliens
    switch (alien.id) {
      case 'humungousaur':
        // Assuming the provided model is Ultimate Humungousaur
        return l10n.ultimateHumungousaurName; // Or l10n.humungousaurName if it's regular
      case 'swampfire':
        return alien.isUltimate ? l10n.ultimateSwampfireName : l10n.swampfireName;
      // Add cases for other aliens based on app_en.arb keys
      // Example:
      // case 'bigchill':
      //   return alien.isUltimate ? l10n.ultimateBigChillName : l10n.bigChillName;
      default:
        // Fallback using the names directly from the Alien model if not found in l10n
        return alien.getLocalizedName(omnitrixProvider.currentLanguage);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Pass context to provider if needed for navigation initiated from provider
    // Provider.of<OmnitrixProvider>(context, listen: false).setContext(context);
    // However, navigation is handled here for transform and settings

    final omnitrixProvider = Provider.of<OmnitrixProvider>(context);
    final selectedAlien = omnitrixProvider.selectedAlien;
    final screenSize = MediaQuery.of(context).size;
    final dialSize = screenSize.width * 0.6; // Adjust size as needed
    final buttonSize = screenSize.width * 0.25;
    final AppLocalizations l10n = AppLocalizations.of(context)!; // Get localizations instance

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          color: Colors.black,
        ),
        child: Stack(
          children: [
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  // Alien Name Display using Localizations
                  Text(
                    _getLocalizedAlienName(context, selectedAlien),
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.secondary, // Green accent
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      shadows: [
                         Shadow( // Add a subtle glow
                           blurRadius: 10.0,
                           color: Theme.of(context).colorScheme.secondary.withOpacity(0.7),
                           offset: Offset(0, 0),
                         ),
                      ]
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 30),

                  // Interactive Omnitrix Dial
                  OmnitrixDial(
                    size: dialSize,
                    color: Theme.of(context).colorScheme.primary,
                    accentColor: Theme.of(context).colorScheme.secondary,
                    onRotateClockwise: omnitrixProvider.isTransforming ? () {} : () => omnitrixProvider.selectNext(), // Disable during transform
                    onRotateCounterClockwise: omnitrixProvider.isTransforming ? () {} : () => omnitrixProvider.selectPrevious(), // Disable during transform
                    // TODO: Pass selected alien symbol/image to the dial
                  ),
                  SizedBox(height: 40),

                  // Transform Button
                  GestureDetector(
                    onTap: omnitrixProvider.isTransforming
                        ? null
                        : () async {
                            // Store context before async gap
                            final navContext = context;
                            await omnitrixProvider.transform();
                            // Check if context is still mounted before navigating
                            if (navContext.mounted) {
                               Navigator.push(
                                 navContext,
                                 MaterialPageRoute(
                                   builder: (context) => selectedAlien.is3d
                                       ? AlienDisplayScreen3D(alien: selectedAlien)
                                       : AlienDisplayScreen2D(alien: selectedAlien),
                                 ),
                               );
                            }
                          },
                    child: Container(
                      width: buttonSize,
                      height: buttonSize,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: omnitrixProvider.isTransforming ? Colors.grey[700] : Theme.of(context).colorScheme.primary, // Green, greyed out when transforming
                        boxShadow: [
                          BoxShadow(
                            color: omnitrixProvider.isTransforming
                                ? Colors.transparent
                                : Theme.of(context).colorScheme.primary.withOpacity(0.7),
                            blurRadius: 10,
                            spreadRadius: 2,
                          ),
                        ],
                        border: Border.all(color: Colors.black, width: 2) // Add border for definition
                      ),
                      child: Center(
                        child: omnitrixProvider.isTransforming
                            ? CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).colorScheme.secondary),
                              )
                            : Icon(
                                Icons.sync, // Placeholder for transform symbol
                                color: Colors.black,
                                size: buttonSize * 0.6,
                              ),
                      ),
                    ),
                  ),

                  // Remove Arrows as dial handles selection now
                  SizedBox(height: 60), // Adjust spacing if needed

                ],
              ),
            ),
            // Settings Button (Top Right)
            Positioned(
              top: 40,
              right: 20,
              child: IconButton(
                icon: Icon(Icons.settings, size: 30),
                onPressed: () {
                  // Navigate to Settings Screen
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const SettingsScreen()),
                  );
                },
              ),
            ),
            // Transformation Overlay/Animation Effect
            if (omnitrixProvider.isTransforming)
              Container(
                color: Colors.black.withOpacity(0.7), // Dim background during transform
                child: Center(
                  // Basic transforming text, replace with animation
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator( color: Theme.of(context).colorScheme.secondary),
                      SizedBox(height: 20),
                      Text(
                        l10n.transformingText,
                        style: TextStyle(
                          fontSize: 30,
                          color: Theme.of(context).colorScheme.secondary,
                          fontWeight: FontWeight.bold,
                           shadows: [
                             Shadow(
                               blurRadius: 15.0,
                               color: Theme.of(context).colorScheme.secondary.withOpacity(0.9),
                               offset: Offset(0, 0),
                             ),
                          ]
                        ),
                      ),
                    ],
                  )
                ),
              ),
          ],
        ),
      ),
    );
  }
}

