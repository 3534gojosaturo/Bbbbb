import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart'; // Correct import for generated localizations

import 'controllers/omnitrix_provider.dart';
import 'views/omnitrix_screen.dart';

void main() {
  // Ensure Flutter bindings are initialized
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => OmnitrixProvider(),
      child: Consumer<OmnitrixProvider>(
        builder: (context, omnitrixProvider, child) {
          return MaterialApp(
            // Use AppLocalizations for the title
            onGenerateTitle: (context) => AppLocalizations.of(context)!.appTitle,
            localizationsDelegates: AppLocalizations.localizationsDelegates, // Use generated delegates
            supportedLocales: AppLocalizations.supportedLocales, // Use generated locales
            locale: Locale(omnitrixProvider.currentLanguage, ''), // Set locale based on provider
            theme: ThemeData(
              brightness: Brightness.dark,
              primarySwatch: Colors.green,
              scaffoldBackgroundColor: Colors.black,
              fontFamily: 'Roboto', // Placeholder, consider a more thematic font
              // Define a green accent color consistent with Ben 10
              colorScheme: ColorScheme.dark(
                primary: Colors.green[700]!,
                secondary: Colors.greenAccent[400]!,
                surface: Colors.black,
                background: Colors.black,
                onPrimary: Colors.white,
                onSecondary: Colors.black,
                onSurface: Colors.white,
                onBackground: Colors.white,
                error: Colors.redAccent,
                onError: Colors.black,
              ),
              elevatedButtonTheme: ElevatedButtonThemeData(
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.black, backgroundColor: Colors.greenAccent[400], // Text color
                ),
              ),
              iconButtonTheme: IconButtonThemeData(
                 style: IconButton.styleFrom(
                   foregroundColor: Colors.greenAccent[400], // Icon color
                 )
              ),
              appBarTheme: AppBarTheme(
                backgroundColor: Colors.grey[900],
                foregroundColor: Colors.greenAccent[400], // Title text color
              ),
              textTheme: TextTheme(
                 // Ensure default text is visible on black background
                 bodyMedium: TextStyle(color: Colors.white),
                 bodyLarge: TextStyle(color: Colors.white),
                 titleMedium: TextStyle(color: Colors.white),
                 titleLarge: TextStyle(color: Colors.white),
              )
            ),
            home: const OmnitrixScreen(), // Use the actual screen
          );
        },
      ),
    );
  }
}

