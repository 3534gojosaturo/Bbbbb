package com.example.omnitrix_simulator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
